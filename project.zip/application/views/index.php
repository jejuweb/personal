<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>기본페이지</title>

  <meta name="title" content="">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport' />
  <link rel="stylesheet" type="text/css" href="<?=AST?>css/init.css" />
  <link rel="stylesheet" type="text/css" href="<?=AST?>less/style.min.css" />


</head>
<body>
  스터디
</body>
</html>