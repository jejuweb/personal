<?php defined('BASEPATH') OR exit('No direct script access allowed');

function minifier(){
  $AST = DOCUMENT.substr( AST, 1 );
  // $CMN = DOCUMENT.substr( CMN, 1 );
  $CMN = DOCUMENT.'project/'.substr( CMN, 1 );
  include $CMN.'minifier/lessc.inc.php';
  $minify = new lessc;

  /*Less*/
  $minify->compileFile( $AST."less/style.less" , $AST."/less/style.css" , $AST."/less/style.min.css" );

  /*Js*/
  // $minify->jsMinify( $AST."js/default.js" , $AST."js/script.min.js" );

}


