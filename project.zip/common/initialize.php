<?php
defined('BASEPATH') OR exit('No direct script access allowed');


/*
|--------------------------------------------------------------------------
| DEFAULT DEFINE
|--------------------------------------------------------------------------
*/

define('HOME', 'http://'.$_SERVER['HTTP_HOST']); // home
define('RATH', '/');
define('DURL', HOME.$_SERVER['REQUEST_URI']); // 현재경로
define('USIP', $_SERVER['REMOTE_ADDR']); // 유저 아이피

