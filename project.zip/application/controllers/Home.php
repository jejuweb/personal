<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

  function __construct() {
    parent::__construct();
    minifier(); // 압축 컴파일러
  }

  function _remap( $method, $params = array() ) {
    if ( ! method_exists( $this, $method ) ) alert( "잘못된 접근 입니다." );
    $this->{"{$method}"}( $params );
  }

  public function index() {
    $this->load->view( 'index' );
  }


} // Home
